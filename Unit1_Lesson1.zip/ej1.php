<?php
    
    $variable = 3;
    $number1 = -10;
    $number2 = 10;
    for($number1; $number1<=$number2; $number1++)
    {
        echo $variable." by ".$number1." is ".$number1*$variable."<br>";
    }


?>